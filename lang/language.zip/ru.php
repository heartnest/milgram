<?php

session_start(); 

/******** added 29/07/2014 *********/

$targetid = $_SESSION['target_id'];

if ($targetid == '123') {
	$targ_description = "Target T is fashion designer XYZ.";
	$targ_title = "About the target";
}else if ($targetid == '321') {
	$targ_description = "Target T is studente";
	$targ_title = "About the target";
}


/******** end 29/07/2014 *********/

/***************  COMMON ******************/

$lan = 'en';
$HEAD_TITLE_LEFT = "Мильграм Перезагрузить!";
$HEAD_TITLE_RIGHT_INTRO = "Введение";
$HEAD_TITLE_RIGHT_REPLY = "ответ";
$HEAD_TITLE_RIGHT_END = "конец";
$FOOT_COPYRIGHT = "Copyright © 2014 Мильграм Тест CSE UNIBO авторское право";

/***************  PAGE ONE ******************/

$P_TITLE= "Добро пожаловать на проект Мильграма";
$P_BUTTON_REFUSE = "отказываться";
$P_BUTTON_ACCEPT = "принимать";
$P_BODYPARAONE="The aim of this experiment is to understand the impact of technology on our communication channels. 
With your help we are trying to reach the target &quot;<span id='targ' class='btn btn-default' data-placement='top' data-content='$targ_description' data-original-title='$targ_title'>T</span>&quot;. In case you know him, please forward the message to T,
otherwise,  <strong>please</strong> forward the message to your knowns who might know T <strong>directly or indirectly</strong>.
			";
$P_BODYPARATWO ="By participating you get a chance to win the <strong><a target='_blank' href='luckydraw.php?lan=ru'>LUCKY DRAW</a></strong>. You can contribute in this experiment by answering 
few questions, which takes 2 minutes (trust us). Your data will be stored anonymously and no data will be 
made public in future.";
$P_BODY_LOW = "Please feel free to contact us for any queries : <strong>connect@cs.unibo.it</strong> <br />We will more than happy to answer, even if it is just a hi comes from you.";

/***************  PAGE TWO ******************/

$PP_QONE = "Пожалуйста, расскажите, как вы получили сообщение";
$PP_QTWO = "Кто ты? (Использование электронной почты или номер мобильного телефона в качестве идентификатора)";
$PP_QTHREE = "Пожалуйста, используйте ваш реальную информацию, с Вами свяжется за результат нашей розыгрыше.";
$PP_QFOUR = "Выберите один из сетей, с которой вы получили сообщение.";
$PP_QFIVE = "Кто вас связаться? (Вставьте идентификатор отправителя т.е. электронную почту или мобильный телефон пожалуйста)";
$PP_QSIX = "Какие сети вы будете пытаться направить эту informaHon для selecHng своим друзьям";
$PP_OP1 = "E-mail";
$PP_OP2 = "Face2Face";
$PP_OP3 = "<input type='text' class='form-control' placeholder='другие (опционально)' />";
$PP_BUTT1= "назад";
$PP_BUTT2= "следующий";

/***************  PAGE THREE ******************/

$PPP_FIRST = "Спасибо! Один Последний пользу";
$PPP_MAIN = "Чтобы убедиться, что вы становитесь получить перечисленные для розыгрыше, скопируйте вставьте следующий шаблон сообщения 
         своим друзьям, которые могут быть полезными в достижении целевых T. Мы будем знать это наверняка, если у вас есть 
         направил это сообщение или нет;) Все лучшее для розыгрыше :)!!";
$PPP_NOTE = "Хотя следующий шаблон доступен, почему бы вам не отправить личное сообщение своим друзьям.";
$PPP_LETTER = "Привет  , 
Существует интересный эксперимент происходит в университете Болоньи. Хорошо, есть лотерея (2 приза), если вы участвуете и направить его своим друзьям. Ниже приводится ссылка на участие в проекте. Пожалуйста, примите участие и давайте выиграть призы :)
http://m.web.cs.unibo.it/?t=$targetid
My ID is :";
$PPP_LAST = "Мы пересылки сообщения на адрес электронной почты, если вы забыли.";




// NEW ADDED 27/07/2014


/***************  PAGE SORRY ******************/

$PPPP_SORRYCONTENT = "to do ...";

/***************  SEO HTML TITLES ******************/
$PAGE1TITLE = "to do .. ";
$PAGE2TITLE = "to do .. ";
$PAGE3TITLE = "to do .. ";
$PAGESTITLE = "to do ..  ";
$PAGEDRAWTITLE = "to do .. ";

/**************** LUCKY DRAW  *******************/

$LUCKDRAWINSTRUCTIONS = "to do .. ";

/***************  JS ******************/

$ERR_SENDER = "to do ...";
$ERR_FORMAT = "to do ...";


/******** new added, 10 - 09 - 2015 ***************/

$PPP_CLICKEICON = "Click icons to share on various networks";
$PALL_EXPINFO = "Experiment Information";
$PALL_STATEMENT = "Privacy Statement";




?>