<?php

session_start(); 

/******** added 29/07/2014 *********/

$targetid = $_SESSION['target_id'];

if ($targetid == '123') {
	$targ_description = "Target T is fashion designer XYZ.";
	$targ_title = "About the target";
}else if ($targetid == '321') {
	$targ_description = "Target T is studente";
	$targ_title = "About the target";
}


/******** end 29/07/2014 *********/


/***************  COMMON ******************/

$lan = 'en';

$HEAD_TITLE_RIGHT_INTRO = "Benvenuti";
$HEAD_TITLE_RIGHT_REPLY = "Rispondere";
$HEAD_TITLE_RIGHT_END = "Condividere";
$FOOT_COPYRIGHT = "Copyright © 2014 - 2015 CSE UNIBO";

/***************  PAGE ONE ******************/

$P_TITLE= "Benvenuti";
$P_BUTTON_ACCEPT = "Avanti";

// to-do ...
$P_BODYPARAONE="With your help we are trying to reach the target &quot;<span id='targ' data-toggle='modal' data-target='#dialog'>$targ_title</span>&quot;.  In case you
know him personally please forward the message to $targ_title, otherwise, please forward the message to someone you know personally who might know $targ_title (directly or indirectly).";
$P_BODYPARATWO ="<label>By participating you get a chance to win an iPad Air.</label>";
$P_BODY_LOW = "Please feel free to contact us for any question : <strong>connect@cs.unibo.it</strong> ";


$P_BODYPARATHREE = "Taking part in this study is entirely up to you. You have the right to refuse to participate in this study. If you decide to take part, you may choose to pull out of the study at any time without giving a reason and without any negative impact. If you choose to participate in the survey, you understand that your responses to the survey questions will be stored in the severs of the University of Bologna. All information is kept confidential. That means it is accessible only by the investigators (i.e., password-protected) and is not published. Your anonymity will be achieved by not associating your name with data collected during the study. Participants will not be identified in any reports or publications.
<br/>
By completing the survey you are providing your consent to use the data for purposes of research. 
<br/>
Please indicate that you understand the information presented above, and consent to participate in this study.";

$P_CONSUS = "I understand and consent to participate in this study.";

/***************  PAGE TWO ******************/

$PP_QONE = "Ci dite come avete ricevuto la notizia per favore.";
$PP_QTWO = "Inserire il vostro email oppure numero di cellulare per favore.";
$PP_QTHREE = "Il contatto viene usato per informarvi i risultati di luckydraw";
$PP_QFOUR = "Selezionate i social dai quali avete ricevuto questa iniziativa";
$PP_QSIX = "Quali social intendi di condividere le informazioni?";
$PP_OP1 = "Email";
$PP_OP2 = "di persona";
$PP_OP3 = "altri(opzionali)";
$PP_BUTT1= "Indietro";
$PP_BUTT2= "Avanti";

$PP_WARNING2 = "Selezionate per favore i social dove avete ricevuto questa iniziativa. ";
$PP_WARNINGTOP = "Alcuni campi sono vuoti, si prega di compilare su tutti i campi";
$PP_WHICHYEAR = "Quando sei nato ?";
$PP_WHICHNET = "Quali social intendi di condividere le informazioni?";
$PP_SEX1 = "Sesso";
$PP_SEX2 = "Maschio";
$PP_SEX3 = "Femmine";
$PP_SEX4 = "Preferisco non dire";

/***************  PAGE THREE ******************/

$PPP_FIRST = "Avete quasi finito";
$PPP_MAIN = "Copiate e girate il seguente messaggio ai vostri social preferiti. Siete liberi di modificare il messaggio ma non toccate il link.
";
$PPP_LETTER = "Ciao , 
Sto partecipando un Esperimento da univeristà di Bologna. E stiamo cercando di arrivare $targ_title, mi puoi aiutare ?
http://milgram.cs.unibo.it/?t=$targetid&&my=$uidCoded";

$PPP_LAST = "Grazie della collaborazione, se riusciamo a raggiungere il target tramite il tuo aiuto, sarai considerato un candidato per il luckydraw.";




// NEW ADDED 27/07/2014


/***************  PAGE SORRY ******************/

$PPPP_SORRYCONTENT = "Apprezziamo tantissmo se potessi contribuirci. Grazie e arrivederci";



/***************  SEO HTML TITLES ******************/
$PAGE1TITLE = "Benvenuti | Milgram Experiment Project | Disi Unibo";
$PAGE2TITLE = "messaggio | Milgram Experiment Project | Disi Unibo";
$PAGE3TITLE = "Grazie | Milgram Experiment Project | Disi Unibo";
$PAGESTITLE = "Peccato ... | Milgram Experiment Project | Disi Unibo";
$PAGEDRAWTITLE = "Lucky Draw | Milgram Experiment Project | Disi Unibo";



/***************  JS ******************/

$ERR_SENDER = "ID mittente inserito non è corretto, le preghiamo di controllare con attenzione";
$ERR_FORMAT = "formato dell&apos;input non è corretto.";


/******** new added, 10 - 09 - 2015 ***************/

$PPP_CLICKEICON = "Per condividerlo su altri social, si prega di cliccare sulle seguenti icone";
$PALL_EXPINFO = "Informazione Esperimento";
$PALL_STATEMENT = "Informazione Privacy";


?>